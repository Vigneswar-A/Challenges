import init, { flip_coin, get_state, buy_upgrade } from './pkg/unfair_wasm_game.js';

const coinContainer = document.getElementById('coin-container');
const flipBtn = document.getElementById('flip-btn');
const logContainer = document.getElementById('log-container');
const flagArea = document.getElementById('flag-area');
const musicBtn = document.getElementById('music-toggle');


const sfxFlip = new Audio('assets/flip.mp3');
const bgMusic = new Audio('assets/shanty.mp3');


bgMusic.loop = true;
bgMusic.volume = 0.3;
sfxFlip.volume = 0.5;

let isMusicPlaying = true; 
let isFlippingAnimationInProgress = false;
let isWon = false;
let currentFlipSpeedMs = 500; 
let totalFlips = 0; 


const COSTS_CHANCE = [0.01, 0.10, 1.00, 10.00, 100.00, "MAX"];
const COSTS_COMBO  = [0.01, 0.10, 1.00, 10.00, 100.00, "MAX"];
const COSTS_SPEED  = [0.01, 0.10, 1.00, 10.00, 100.00, "MAX"];
const COSTS_VALUE  = [0.25, 1.00, 6.25, 100.00, "MAX"];


const TXT_HEADS = [
    "A fine toss! The Bearcat smiles.",
    "Steady as she goes!",
    "Aye! Another mark for the captain.",
    "The winds be in our favor!",
    "Keep the momentum, crew!"
];

const TXT_TAILS = [
    "Curses! Back to the scrubbin' decks.",
    "The sea be cruel today.",
    "A bad omen... Streak broken.",
    "Barnacles! Try again, matey.",
    "Davey Jones takes yer luck."
];

const TXT_MILESTONE = [
    "Ye getting yer sea legs now!",
    "A true sailor in the making!",
    "By Neptune's beard, look at ye go!",
    "Legend says the 10th streak holds the key..."
];


function toggleMusic() {
    if (isMusicPlaying) {
        bgMusic.pause();
        musicBtn.innerText = "🎵 PLAY MUSIC";
        isMusicPlaying = false;
    } else {
        bgMusic.play().catch(e => console.log("Audio play failed:", e));
        musicBtn.innerText = "🔇 MUTE MUSIC";
        isMusicPlaying = true;
    }
}

function tryStartMusic() {
    bgMusic.play().then(() => {
        musicBtn.innerText = "🔇 MUTE MUSIC";
    }).catch(() => {
        console.log("Autoplay blocked. Waiting for interact...");
        musicBtn.innerText = "🔇 MUTE MUSIC";
        const playOnInteraction = () => {
            if (isMusicPlaying) bgMusic.play();
            document.removeEventListener('click', playOnInteraction);
        };
        document.addEventListener('click', playOnInteraction);
    });
}


function updateUI() {
    const state = JSON.parse(get_state());
    
    document.getElementById('streak-display').innerText = state.streak;
    document.getElementById('money-display').innerText = parseFloat(state.money).toFixed(2);
    document.getElementById('chance-display').innerText = state.chance;

    currentFlipSpeedMs = state.flip_speed_ms;

    updateButton('chance', state.lvl_chance, COSTS_CHANCE);
    updateButton('combo', state.lvl_combo, COSTS_COMBO);
    updateButton('speed', state.lvl_speed, COSTS_SPEED);
    updateButton('value', state.lvl_value, COSTS_VALUE);
}

function updateButton(type, level, costArray) {
    const btn = document.getElementById(`btn-${type}`);
    const lblCost = document.getElementById(`cost-${type}`);
    const lblLvl = document.getElementById(`lvl-${type}`);
    
    lblLvl.innerText = `LVL ${level}`;
    
    if(level >= costArray.length - 1) {
        lblCost.innerText = "MAXED";
        btn.classList.add("disabled");
        btn.disabled = true;
    } else {
        lblCost.innerText = `$${costArray[level].toFixed(2)}`;
        btn.classList.remove("disabled");
        btn.disabled = false;
    }
}

window.buy = function(type) {
    
    if(buy_upgrade(type)) {
        let msg = "";
        switch(type) {
            case 'chance': msg = "Rigged the sails! (Win Chance +)"; break;
            case 'combo': msg = "Sharpened the cutlass! (Combo +)"; break;
            case 'speed': msg = "Greased the coin! (Speed +)"; break;
            case 'value': msg = "Polished the gold! (Value +)"; break;
        }
        addLog(msg, "upgrade");
        updateUI();
    } else {
        addLog("Not enough doubloons, matey!", "error");
    }
}


function addLog(text, type = "info") {
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    
    if (type === "heads") {
        entry.classList.add('log-heads');
        entry.innerHTML = `> <b>HEADS</b>: ${text}`;
    } else if (type === "tails") {
        entry.classList.add('log-tails');
        entry.innerHTML = `> TAILS: ${text}`;
    } else if (type === "milestone") {
        entry.style.color = "#d4af37"; 
        entry.style.fontWeight = "bold";
        entry.style.borderBottom = "1px solid #d4af37";
        entry.innerHTML = `★ <b>LOG UPDATE:</b> ${text}`;
    } else if (type === "upgrade") {
        entry.style.color = "#4169e1"; 
        entry.innerHTML = `> ${text}`;
    } else if (type === "win") {
        entry.className = 'flag-revealed';
        entry.innerText = text;
        
        flagArea.innerText = text;
        flagArea.className = 'flag-revealed';
        logContainer.appendChild(entry); 
        return; 
    } else {
        entry.innerText = `> ${text}`;
    }
    
    logContainer.appendChild(entry);
    logContainer.scrollTop = logContainer.scrollHeight;
}

function getRandomFlavor(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function performFlip() {
    if (isFlippingAnimationInProgress || isWon) return;
    isFlippingAnimationInProgress = true;
    flipBtn.disabled = true;
    
    sfxFlip.currentTime = 0;
    sfxFlip.play().catch(e => console.log("SFX failed", e));

    
    const prevStreak = parseInt(document.getElementById('streak-display').innerText);

    const result = flip_coin();
    totalFlips++;

    
    coinContainer.style.animation = 'none';
    coinContainer.offsetHeight; 

    coinContainer.style.animationDuration = `${currentFlipSpeedMs / 1000}s`;

    if (result === "TAILS") {
        coinContainer.style.animationName = 'flipTails';
        coinContainer.style.transform = 'rotateY(180deg)';  
    } else {
        coinContainer.style.animationName = 'flipHeads';
        coinContainer.style.transform = 'rotateY(0deg)'; 
    }

    setTimeout(() => {
        
        if (totalFlips % 100 === 0) {
            addLog(`${totalFlips} FLIPS! A veteran of the sea!`, "milestone");
        } else if (totalFlips % 10 === 0) {
            addLog(`${totalFlips} total flips recorded.`, "milestone");
        }

        
        if (result.startsWith("BCCTF{")) {
            addLog("The Cursed Coin breaks!", "heads");
            addLog(result, "win");
            isWon = true;
        } 
        else if (result === "HEADS") {
            const flavor = getRandomFlavor(TXT_HEADS);
            addLog(flavor, "heads");
        } 
        else {
            
            let flavor = getRandomFlavor(TXT_TAILS);
            if (prevStreak >= 3) {
                flavor = `Lost a streak of ${prevStreak}! The sea is cruel.`;
            }
            addLog(flavor, "tails");
        }

        updateUI();
        isFlippingAnimationInProgress = false;
        flipBtn.disabled = false;
    }, currentFlipSpeedMs);
}

async function runGame() {
    await init();
    updateUI();

    flipBtn.addEventListener('click', performFlip);
    musicBtn.addEventListener('click', toggleMusic);

    tryStartMusic();
}

runGame();